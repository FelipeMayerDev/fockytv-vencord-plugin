// SPDX-License-Identifier: GPL-3.0-or-later
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import { transformSync } from "esbuild";
import { mergeQueueState } from "./github-queue";
import { repositoryName } from "./github";

const source = readFileSync(new URL("./index.tsx", import.meta.url), "utf8");
const javascript = (code: string) => transformSync(code, { loader: "tsx", jsxFactory: "React.createElement" }).code;
const React = { createElement: (type: unknown, props: unknown, ...children: unknown[]) => ({ type, props, children }) };

test("GitHub settings shortcut and direct opening require a local token", () => {
    const store = { githubToken: "" };
    let opened = 0;
    const open = new Function("settings", "openModal", "markGithubQueueSeen", javascript(
        source.slice(source.indexOf("function openGithub("), source.indexOf("const GithubIcon ="))
    ) + "\nreturn openGithub;")({ store }, () => opened++, () => {});
    const trees: any[][] = [];
    const about = new Function("React", "settings", "Button", "openPanel", "openGithub", "UpdateControls", javascript(
        "const about = " + source.slice(source.indexOf("settingsAboutComponent: ") + "settingsAboutComponent: ".length, source.indexOf("    flux: {")).trim().replace(/,$/, "")
    ) + "\nreturn about;")(
        { createElement: (_type: unknown, _props: unknown, ...children: any[]) => { trees.push(children); return {}; } },
        { use: () => store }, "Button", () => {}, open, "UpdateControls"
    );
    for (const [token, expected] of [["", 0], ["   ", 0], ["configured", 1], ["", 1]] as const) {
        store.githubToken = token;
        open();
        assert.equal(opened, expected);
        trees.length = 0;
        about();
        assert.equal(trees.some(children => children.includes("Abrir GitHub")), !!token.trim());
    }
});

test("GitHub starts blank and its button reacts to adding and removing a token", () => {
    const definitions = new Function("definePluginSettings", "OptionType", "repositoryName", `
        ${javascript(source.slice(source.indexOf("const settings ="), source.indexOf("// Token como senha")))}
        return settings;
    `)((value: unknown) => value, {}, repositoryName);
    assert.equal(definitions.githubToken.default, "");
    assert.equal(definitions.githubRepository.default, "");
    assert.equal(definitions.githubRepository.isValid(""), true);
    assert.equal(definitions.githubRepository.isValid("dona/projeto"), true);
    assert.equal(definitions.githubRepository.isValid("invalid"), false);

    const store = { githubToken: "", githubRepository: "dona/projeto" };
    const button = new Function("React", "settings", "PanelButton", "GithubIcon", "openGithub", "useGithubQueue", "githubQueueRequest", `
        ${javascript(source.slice(source.indexOf("function GithubButton("), source.indexOf("const jiraRequest:")))}
        return GithubButton;
    `)(React, { use: () => store }, "PanelButton", "GithubIcon", () => {}, () => ({ items: [], history: [], merged: [], error: "", updated: null }), () => {});
    for (const token of ["", "   ", "configured", ""]) {
        store.githubToken = token;
        assert.equal(button({}) !== null, !!token.trim());
        assert.equal(store.githubRepository, "dona/projeto", "Saved choices survive token changes");
    }
});

test("GitHub panel waits for a project and preserves saved repository selections", () => {
    const panelSource = readFileSync(new URL("./github-panel.tsx", import.meta.url), "utf8");
    // Run the real hooks before rendering JSX; no Discord runtime is needed.
    const code = panelSource.slice(panelSource.indexOf("export function GithubPanel("), panelSource.indexOf("    const chooseRepository ="))
        .replace("export function", "function") + "\nreturn repository; } return GithubPanel;";
    for (const repository of ["", "dona/projeto"]) {
        const effects: (() => unknown)[] = [], loaded: string[] = [];
        const panel = new Function("useState", "useEffect", "useRef", "loadGithub", javascript(code))(
            (value: unknown) => [value, () => {}], (effect: () => unknown) => effects.push(effect), () => ({ current: {} }),
            (_request: unknown, name: string) => { loaded.push(name); return Promise.resolve({ errors: [] }); }
        );
        assert.equal(panel({ context: { repository, authenticated: false } }), repository);
        effects[3](); // Project data effect, after scroll, account and repository list effects.
        assert.deepEqual(loaded, repository ? [repository] : []);
    }
});


test("GitHub badge and hover reflect Merge Queue position and live status", () => {
    const queue = { items: [{ number: 42, title: "Fix CI", baseRefName: "main", mergeQueueEntry: { position: 2, state: "QUEUED", headCommit: null } }], merged: [] as { number: number; }[], error: "", updated: 1000 };
    const button = new Function("React", "settings", "PanelButton", "GithubIcon", "openGithub", "useGithubQueue", "githubQueueRequest", "mergeQueueState", "ActionIcon", `
        ${javascript(source.slice(source.indexOf("function GithubButton("), source.indexOf("const jiraRequest:")))}
        return GithubButton;
    `)(React, { use: () => ({ githubToken: "configured", githubRepository: "dona/projeto" }) }, "PanelButton", "GithubIcon", () => {}, () => queue, () => {}, mergeQueueState, "ActionIcon");
    const render = () => button({});
    const tooltip = () => JSON.stringify(render().props.tooltipText);
    const badge = () => render().props.icon({}).children[1];
    assert.deepEqual(badge().children, [1]);
    assert.match(tooltip(), /"#",42," · ","Na fila"/);
    assert.match(tooltip(), /"data-state":"running"/);
    assert.doesNotMatch(tooltip(), /Fix CI|Posição|Checks/, "Hover stays compact: number and status only");
    queue.items[0].mergeQueueEntry.state = "AWAITING_CHECKS";
    assert.match(tooltip(), /Aguardando checks/);
    queue.error = "Sem permissão";
    assert.deepEqual(badge().children, ["!"]);
    assert.match(tooltip(), /Dados desatualizados/);
    queue.error = "";
    queue.items = [];
    assert.equal(badge(), "");
    assert.match(tooltip(), /Nenhum PR na Merge Queue/);
    queue.merged = [{ number: 7 }];
    assert.match(tooltip(), /"#",7," · ","Mesclado"/);
    assert.match(tooltip(), /"data-state":"merged"/);
    assert.doesNotMatch(tooltip(), /Nenhum PR/);
});
