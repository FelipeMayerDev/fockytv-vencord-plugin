// SPDX-License-Identifier: GPL-3.0-or-later
import { RenderModalProps } from "@vencord/discord-types";
import { Modal, React, useEffect, useState } from "@webpack/common";

import { formatTime, musicPlayer } from "./music";
import { Search } from "./music-panel";
import { watchParty, youtubeId } from "./watch-party";

export function useWatch(player: ReturnType<typeof watchParty>, ticking = false) {
    const [, render] = useState(0);
    useEffect(() => {
        const unsubscribe = player.subscribe(() => render(value => value + 1));
        const timer = ticking ? setInterval(() => render(value => value + 1), 1000) : undefined;
        return () => { unsubscribe(); clearInterval(timer); };
    }, [player, ticking]);
    return player.snapshot();
}

// Play/pausa e posição valem para todos na call; a barra só envia ao soltar para não inundar a sala.
export function WatchControls({ player, setVolume }: { player: ReturnType<typeof watchParty>; setVolume(value: number): void; }) {
    const { state, connected, title, loading, error, volume } = useWatch(player, true);
    const [seek, setSeek] = useState<number>();
    const duration = player.duration();
    const position = Math.min(duration, seek ?? player.position());
    const commit = () => { if (seek !== undefined && state) player.control(state.playing, seek); setSeek(undefined); };
    const stop = (event: React.SyntheticEvent) => event.stopPropagation();
    return <div className="fockytv-watch-controls" onClick={stop} onDoubleClick={stop} onMouseDown={stop} onPointerDown={stop}>
        <span className="fockytv-watch-status" role={error ? "alert" : undefined}>{error || (loading ? `Baixando… ${title}` : title)}</span>
        <div>
            <button type="button" className="fockytv-player-button" disabled={!connected || !state} onClick={() => player.control(!state!.playing)}>{state?.playing ? "Pausar" : "Play"}</button>
            <input type="range" aria-label="Posição do vídeo para todos" min={0} max={duration} step={0.1} disabled={!connected || !duration || !state}
                value={position} onChange={event => setSeek(Number(event.currentTarget.value))} onPointerUp={commit} onKeyUp={commit} />
            <span>{formatTime(position)} / {formatTime(duration)}</span>
        </div>
        <div>
            <label className="fockytv-music-volume">Volume <input type="range" aria-label="Volume do vídeo" min={0} max={100} value={Math.round(volume * 100)}
                onChange={event => setVolume(Number(event.currentTarget.value) / 100)} /></label>
            <button type="button" className="fockytv-player-button" disabled={!connected || !state?.queue || state.queue.length < 2} onClick={() => player.next()}>Próximo</button>
            <button type="button" className="fockytv-player-button" onClick={() => player.listen(false)}>Sair da watch party</button>
        </div>
    </div>;
}

export function WatchPartyPanel({ player, music, ...props }: RenderModalProps & {
    player: ReturnType<typeof watchParty>; music: ReturnType<typeof musicPlayer>;
}) {
    const [link, setLink] = useState("");
    const { channel, state, connected, title } = useWatch(player);
    useEffect(() => { if (!channel) props.onClose(); }, [channel]);
    const add = (id: string, title?: string) => { player.listen(true); player.add(id, title); };
    return <Modal {...props} title="Watch party do YouTube" subtitle={connected ? "Adicione vídeos à playlist da call; a sincronização é automática" : "Conectando ao servidor…"} size="md">
        <div className="fockytv-watch">
            <form onSubmit={event => { event.preventDefault(); const id = youtubeId(link); if (id) { add(id); setLink(""); } }}>
                <input className="fockytv-music-input" aria-label="Link do YouTube ou ID do vídeo" placeholder="Cole um link do YouTube" value={link} onChange={event => setLink(event.currentTarget.value)} />
                <button type="submit" className="fockytv-music-control" disabled={!connected || !youtubeId(link) || (state?.queue?.length ?? 0) >= 100}>Adicionar à playlist</button>
            </form>
            {connected && (state?.queue?.length ?? 0) < 100 && <Search player={music} onChoose={add} />}
            {(state?.queue?.length ?? 0) >= 100 && <p className="fockytv-music-hint">A playlist está cheia (100 vídeos).</p>}
            <section aria-label="Playlist da watch party">
                <h3>Playlist</h3>
                {!state?.queue?.length && <p className="fockytv-music-hint">A playlist está vazia. Adicione um vídeo para começar.</p>}
                <ol className="fockytv-music-list">
                    {state?.queue?.map((track, index) => <li key={track.uid} className={`fockytv-music-item${index === 0 ? " is-current" : ""}`}>
                        {index === 0 ? "▶ " : ""}{index === 0 ? title || track.title : track.title}
                    </li>)}
                </ol>
            </section>
        </div>
    </Modal>;
}
