# FockyTV para Vencord

Port do plugin Rust deste projeto para um userplugin TypeScript do Vencord
**desktop** (Discord ou Vesktop com uma build personalizada do Vencord).
Sem dependências adicionais. Licença GPL-3.0-or-later, conforme LICENSE.

## Instalação automática

**Linux x64:**

```sh
curl -fsSL https://raw.githubusercontent.com/FelipeMayerDev/fockytv-vencord-plugin/main/installer/install.sh | bash
```

**Windows x64 — execute no PowerShell:**

```powershell
curl.exe -fL https://raw.githubusercontent.com/FelipeMayerDev/fockytv-vencord-plugin/main/installer/install.ps1 -o "$env:TEMP\fockytv-install.ps1"; if ($LASTEXITCODE -eq 0) { powershell -NoProfile -ExecutionPolicy Bypass -File "$env:TEMP\fockytv-install.ps1" }
```

O instalador identifica Discord (Stable/PTB/Canary) e Vesktop. Se encontrar
mais de um cliente, pergunta em qual instalar. Fecha somente o cliente escolhido,
compila o plugin e ativa **FockyTV** nas configurações. Abra o cliente novamente
quando terminar; entrar em uma chamada ou transmitir não acontece automaticamente.

- **Vesktop:** usa o Vencord embutido com uma build personalizada indicada em
  `state.json`; não injeta nem substitui o aplicativo Vesktop.
- **Discord com Vencord a partir do fonte:** encontra o checkout pela injeção e
  recompila nele, preservando os outros userplugins.
- **Discord sem Vencord:** baixa o fonte oficial, compila com FockyTV e usa o
  instalador oficial do Vencord para injetar a build.
- **Vencord binário sem checkout:** procura o fonte nas pastas comuns ou cria
  uma build separada. Configurações e arquivos antigos são preservados, mas
  userplugins sem fonte não podem ser incorporados à nova build.

Git é instalado se faltar (winget no Windows; gerenciador de pacotes com sudo
no Linux). Node.js 22+ e npm existentes são reutilizados; se não estiverem
presentes, baixa Node.js LTS privado para o instalador e verifica SHA-256.
O pnpm usa a versão declarada no checkout e não precisa de instalação global.
A build desativa o atualizador que poderia substituí-la por Vencord sem o plugin;
para atualizar o FockyTV, execute novamente o mesmo comando.

Discord e Vesktop Flatpak são detectados pelos locais padrão; o instalador
libera apenas a pasta da build para o sandbox. Snap, outras arquiteturas e
instalações portáteis em caminhos personalizados não estão cobertos pela busca
automática. Instale e abra o cliente uma vez antes de executar. Não rode o
instalador inteiro como root; sudo é usado somente para Git/injeção quando necessário.

Para indicar um checkout existente ou escolher um cliente sem menu:

```sh
curl -fsSL https://raw.githubusercontent.com/FelipeMayerDev/fockytv-vencord-plugin/main/installer/install.sh | bash -s -- --client vesktop --source "$HOME/Vencord"
```

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "$env:TEMP\fockytv-install.ps1" -Client discord -Source "$env:USERPROFILE\Vencord"
```

Falhas de compilação restauram o plugin e a build anteriores. Backups da build
ficam em `dist.fockytv-backup-*`, os do plugin em `.fockytv-backups/` e os das
configurações junto ao JSON original. Configuração JSON inválida interrompe a
instalação sem sobrescrever o arquivo. Não apague o checkout: o cliente usa seu
`dist` ao abrir.

O fluxo usa a [CLI oficial do Vencord](https://github.com/Vencord/Installer) e a
[seleção de build do Vesktop](https://github.com/Vencord/Vesktop/blob/main/src/main/vencordFilesDir.ts).
O [GoLiveBypass](https://github.com/bezumiya/GoLiveBypass#instalação-do-plugin-recomendado-para-equicord-vencord-e-vesktop)
foi consultado como referência de instalação.

## Instalação manual

1. Tenha uma cópia do código-fonte do Vencord e suas dependências instaladas.
2. Copie esta pasta inteira para `Vencord/src/userplugins/fockytv`.
3. Na pasta do Vencord, execute `pnpm build`.
4. Para Discord desktop, execute `pnpm inject`. Para Vesktop, selecione a pasta
   `Vencord/dist` na opção de localização personalizada do Vencord.
5. Reinicie o cliente e ative **FockyTV** em Configurações → Vencord → Plugins.
6. Configure a URL base do servidor (sem caminho), nick (vazio usa seu username), FPS e resolução.

Plugins personalizados precisam ser compilados junto com o Vencord; este ZIP
não é um plugin BetterDiscord e não pode ser importado como `.plugin.js`.
Referência: https://docs.vencord.dev/plugins/

## Uso

Com o FockyTV ativado, use o **botão normal de compartilhar tela do Discord**
e escolha tela/janela e qualidade no seletor nativo. A transmissão é enviada
para o FockyTV; o comando normal de parar encerra a publicação. Uma notificação
confirma o início ou informa o erro. Desativar o plugin devolve o botão ao Go Live
(após reiniciar o cliente para remover os patches).

O ícone de TV na barra de mensagens e **Abrir FockyTV** nas configurações abrem
o painel de lives/câmera. O painel também compartilha tela e câmera simultaneamente,
com chaves `nick` e `nick-cam` (limitadas a 32 caracteres), e lista lives a
cada cinco segundos. Use o nick do Discord para ser reconhecido pelo cliente Rust.

O player para ao fechar o painel. Publicações continuam e param com os botões,
a saída da chamada, logout ou desativação do plugin. O encerramento envia DELETE
para liberar a sessão no servidor. Se o processo morrer abruptamente, o servidor
precisa expirar a sessão.

## Limites

- Tela/câmera publicam por WHIP no LiveKit (`/api/livekit/whip`), como o
  cliente Rust atual. O servidor precisa oferecer esse endpoint e anunciar
  endereços de mídia acessíveis aos espectadores, inclusive fora da LAN.
  Encaminhe no roteador as portas configuradas do LiveKit e do ingress WHIP
  (7885/UDP). Em redes sem NAT loopback, a API pode acrescentar o IP local
  aos candidatos WHIP com `LIVEKIT_INGRESS_LAN_IP`.
  O player do painel usa WHEP para lives antigas; lives `engine: livekit`,
  incluindo as publicadas pelo plugin, são assistidas pelo site FockyTV.
- No Windows, respeita **Compartilhar áudio** no seletor do Discord. Uma janela
  captura o áudio do processo escolhido; uma tela mistura os aplicativos,
  excluindo Discord/Vesktop/FockyTV. O preview local é sempre silenciado.
  O helper WASAPI exige Windows 10 build 20348+ ou Windows 11. Em outro sistema
  ou se a captura de som falhar, informa o erro e preserva o vídeo.
- O preview aparece como tile local na chamada do Discord. Usa a captura
  publicada, sem uma segunda sessão de vídeo ou reprodução do próprio áudio.
  O preview informa as dimensões ao Discord e aparece antes da negociação de rede.
- Publicações só confirmam o início após o WebRTC conectar. A coleta ICE usa a configuração
  padrão do cliente, sem depender de STUN externo, e aproveita candidatos já
  coletados se a coleta demorar. A conexão falha após 20 segundos; rede/VPN
  e a porta de mídia do servidor ainda precisam permitir o tráfego WebRTC.
- Câmera não captura microfone; WHEP recebe áudio quando a live o oferece.
- Redireciona o início de tela e o comando de parar do Discord. O estado do
  botão e do preview é local; não cria um Go Live nos servidores Discord nem
  adiciona badges/players FockyTV aos outros participantes. Eles assistem pelo painel
  ou pelo site. O botão nativo de câmera continua sendo o do Discord.
- A fonte escolhida no seletor usa captura desktop do Chromium (tela/janela).
  Fontes especiais, como câmeras escolhidas para Go Live ou o seletor nativo
  de macOS, ainda não são suportadas por essa integração.
- Inclui a liberação local de câmera e compartilhamento do experimento
  `2026-08-video-guard`; não exige GoLiveBypass para liberar os botões.
  Reinicie o Discord após ativar o plugin. Isso não altera bloqueios do servidor.
- Os patches dependem do código interno do Discord e podem precisar de ajuste
  após uma atualização.
- Captura usa as permissões e o seletor do Chromium/Electron. No Linux/Wayland,
  depende do portal disponível e da implementação de captura desktop do cliente.
- Sinalização HTTP usa o helper nativo; esta versão não suporta Vencord no navegador.
- Lives seguem a visibilidade do servidor FockyTV, não as permissões do canal Discord.
- Validado com testes automatizados e build local; captura/player reais ainda
  precisam de teste no cliente conectado ao servidor. A checagem TypeScript
  do checkout usado não apontou erros neste plugin; falha por erros
  preexistentes do GoLiveBypass.

## Verificação

Instalador (Node.js 22+, sem alterar clientes reais):
`node --test installer/install.test.mjs`.
No PowerShell, o bootstrap também pode ser verificado sem downloads reais:
`powershell -NoProfile -ExecutionPolicy Bypass -File installer/bootstrap.test.ps1`.

Com as ferramentas de desenvolvimento do Vencord:
`pnpm exec tsx src/userplugins/fockytv/self-check.ts`.

## Capturador de áudio Windows

`audio-helper.exe` e `audio-helper.cpp` são reutilizados do projeto FockyTV
(`electron/audio-helper/capture.cpp`). O Vencord embute o binário no helper
nativo; na primeira captura ele é materializado na pasta privada do cliente,
com verificação SHA-256. Parar a tela, sair da chamada ou fechar o cliente
encerra o capturador. Buffers preservam frames PCM e têm limite de tamanho.

Recompilação opcional (MinGW):
`x86_64-w64-mingw32-g++ -std=c++17 -O2 -static -o audio-helper.exe audio-helper.cpp -lole32 -lpsapi`.

## Recuperar portas após reiniciar o roteador

No servidor LAN, `scripts/fockytv-upnp.sh` reaplica os encaminhamentos
7885/UDP, 7892/UDP e 7891/TCP para `192.168.1.129`. O timer do systemd
executa após o boot e a cada minuto; falhas ficam no journal e são tentadas
novamente na próxima execução. O roteador precisa manter UPnP habilitado.

Instalação no servidor (o serviço usa o usuário `focky`):

```sh
sudo install -m 755 scripts/fockytv-upnp.sh /usr/local/sbin/fockytv-upnp
sudo install -m 644 scripts/fockytv-upnp.service scripts/fockytv-upnp.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now fockytv-upnp.timer
```

Verificação: `systemctl status fockytv-upnp.timer` e
`journalctl -u fockytv-upnp.service`. Para desativar:
`sudo systemctl disable --now fockytv-upnp.timer`.
Teste sem alterar o roteador: `python3 scripts/check-upnp.py`.
O script restaura as portas; mudanças do IP público ainda exigem atualizar
`LIVEKIT_NODE_IP` na configuração do servidor.
