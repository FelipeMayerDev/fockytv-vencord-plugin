# FockyTV para Vencord

Port do plugin Rust deste projeto para um userplugin TypeScript do Vencord
**desktop** (Discord ou Vesktop com uma build personalizada do Vencord).
Licença GPL-3.0-or-later, conforme LICENSE.

## Instalação automática

**Linux x64:**

```sh
curl -fsSL https://raw.githubusercontent.com/FelipeMayerDev/fockytv-vencord-plugin/main/installer/install.sh | bash
```

**Windows x64 — execute no PowerShell:**

```powershell
irm https://raw.githubusercontent.com/FelipeMayerDev/fockytv-vencord-plugin/main/installer/install.ps1 | iex
```

O instalador identifica Discord (Stable/PTB/Canary) e Vesktop. Se encontrar
mais de um cliente, pergunta em qual instalar. Fecha somente o cliente escolhido,
compila o plugin e ativa **FockyTV** e **FakeNitro** nas configurações. Abra o cliente novamente
quando terminar; entrar em uma chamada ou transmitir não acontece automaticamente.

O servidor padrão é `https://fockytv.felipemayer.com.br`; outro endereço pode ser
definido nas configurações do plugin. Reinstalar atualiza o endereço padrão antigo.

- **Vesktop:** usa o Vencord embutido com uma build personalizada indicada em
  `state.json`; não injeta nem substitui o aplicativo Vesktop.
- **Discord com Vencord a partir do fonte:** encontra o checkout pela injeção e
  recompila nele, preservando os outros userplugins.
- **Discord sem Vencord:** baixa o fonte oficial, compila com FockyTV e usa o
  instalador oficial do Vencord para injetar a build.
- **Vencord binário sem checkout:** procura o fonte nas pastas comuns ou cria
  uma build separada. Configurações e arquivos antigos são preservados, mas
  userplugins sem fonte não podem ser incorporados à nova build.
- **Discord com Equicord:** mesmo fluxo, com o fonte do Equicord, o instalador
  Equilotl e as configurações em `Equicord/settings`. Vesktop não aceita Equicord.

Git é instalado se faltar (winget no Windows; gerenciador de pacotes com sudo
no Linux). Sem winget, ou se ele falhar, o Windows usa MinGit portátil oficial,
verificado por SHA-256 e guardado na pasta do FockyTV, sem exigir administrador.
Node.js 22+ e npm existentes são reutilizados; se não estiverem
presentes, baixa Node.js LTS privado para o instalador e verifica SHA-256.
O pnpm usa a versão declarada no checkout e não precisa de instalação global.
A build desativa o atualizador oficial que poderia substituí-la por Vencord sem o
plugin. O FockyTV verifica atualizações ao abrir e a cada seis horas, e avisa quando
há uma versão nova. O botão **Instalar atualização e fechar o cliente**, no painel
ou nas configurações do FockyTV, inicia o instalador com o cliente correto, preservando
os outros plugins e os backups. Reabra o cliente ao terminar. Nada é instalado apenas
por receber o aviso. Também é possível atualizar repetindo o comando acima.

Ao assistir pelo Discord/Vesktop, use o controle de volume e o mute da própria
transmissão. O áudio respeita também o volume geral de saída e o “ensurdecer”,
com amplificação acima de 100%, sem alterar o volume da voz do usuário.

Discord e Vesktop Flatpak são detectados pelos locais padrão; o instalador
libera apenas a pasta da build para o sandbox. Snap, outras arquiteturas e
instalações portáteis em caminhos personalizados não estão cobertos pela busca
automática. Instale e abra o cliente uma vez antes de executar. Não rode o
instalador inteiro como root; sudo é usado somente para Git/injeção quando necessário.

Para indicar um checkout existente ou escolher um cliente sem menu:

```sh
curl -fsSL https://raw.githubusercontent.com/FelipeMayerDev/fockytv-vencord-plugin/main/installer/install.sh | bash -s -- --client vesktop --source "$HOME/Vencord"
```

```powershell
& ([scriptblock]::Create((irm https://raw.githubusercontent.com/FelipeMayerDev/fockytv-vencord-plugin/main/installer/install.ps1))) -Client discord -Source "$env:USERPROFILE\Vencord"
```

Falhas de compilação restauram o plugin e a build anteriores. Backups da build
ficam em `dist.fockytv-backup-*`, os do plugin em `.fockytv-backups/` e os das
configurações junto ao JSON original. Configuração JSON inválida interrompe a
instalação sem sobrescrever o arquivo. Não apague o checkout: o cliente usa seu
`dist` ao abrir.

O fluxo usa a [CLI oficial do Vencord](https://github.com/Vencord/Installer) e a
[seleção de build do Vesktop](https://github.com/Vencord/Vesktop/blob/main/src/main/vencordFilesDir.ts).
O [GoLiveBypass](https://github.com/bezumiya/GoLiveBypass#instalação-do-plugin-recomendado-para-equicord-vencord-e-vesktop)
foi consultado como referência de instalação.

## Instalação manual

1. Tenha uma cópia do código-fonte do Vencord e suas dependências instaladas.
2. Copie esta pasta inteira para `Vencord/src/userplugins/fockytv`.
3. Na pasta do Vencord, execute `pnpm build`.
4. Para Discord desktop, execute `pnpm inject`. Para Vesktop, selecione a pasta
   `Vencord/dist` na opção de localização personalizada do Vencord.
5. Reinicie o cliente e ative **FockyTV** em Configurações → Vencord → Plugins.
6. Configure a URL base do servidor (sem caminho), FPS e resolução. A live usa sempre seu username do Discord.

Plugins personalizados precisam ser compilados junto com o Vencord; este ZIP
não é um plugin BetterDiscord e não pode ser importado como `.plugin.js`.
Referência: https://docs.vencord.dev/plugins/

## Uso

Com o FockyTV ativado, use o **botão normal de compartilhar tela do Discord**
e escolha tela/janela e qualidade no seletor nativo. A transmissão é enviada
para o FockyTV; o comando normal de parar encerra a publicação. Uma notificação
confirma o início ou informa o erro. A resolução e o FPS escolhidos no Discord
valem desde o início, inclusive no Vesktop. Durante a transmissão, use o menu
nativo de qualidade para alterá-los: a sessão e o áudio são preservados. Uma
falha restaura a configuração anterior e informa o erro; a opção Fonte remove
o limite de altura. A qualidade efetiva continua sujeita à fonte, rede e encoder.
Desativar o plugin devolve o botão ao Go Live
(após reiniciar o cliente para remover os patches).

Quem também tem o plugin vê a live **como um Go Live nativo**: o participante
aparece "AO VIVO" na call e o botão **Assistir transmissão** abre a live no
quadro do próprio Discord (tela cheia, foco e "parar de assistir" incluídos).
O áudio respeita o ensurdecer. A live usa sempre o username do Discord, que é
como os outros a reconhecem na mesma call; a lista é atualizada a cada cinco segundos.

A webcam também aparece automaticamente no quadro de câmera da chamada para quem
tem o plugin, usando a publicação `username-cam`. A imagem remota não é espelhada;
a conexão fecha ao desligar a câmera ou sair do canal. A descoberta leva até cinco segundos.

O botão **Abrir FockyTV** nas configurações abre o painel de lives/câmera. O painel também compartilha tela e câmera simultaneamente,
com chaves `username` e `username-cam` (limitadas a 32 caracteres), e lista lives a
cada cinco segundos.

O player para ao fechar o painel. Publicações continuam e param com os botões,
a saída da chamada, logout ou desativação do plugin. O encerramento envia DELETE
para liberar a sessão no servidor. Se o processo morrer abruptamente, o servidor
precisa expirar a sessão.

## Limites

- Tela/câmera publicam por WHIP no servidor FockyTV, como o cliente Rust atual.
  O player do painel usa WHEP para lives antigas; lives `engine: livekit`,
  incluindo as publicadas pelo plugin, são assistidas pelo Go Live do Discord
  ou pelo site. Para isso o plugin embute o `livekit-client` 2.22.3
  (Apache-2.0, o mesmo do site); a sinalização WebSocket passa pelo processo
  nativo porque o CSP do Discord bloqueia conexões ao servidor FockyTV.
- No Windows, respeita **Compartilhar áudio** no seletor do Discord. Uma janela
  captura o áudio do processo escolhido; uma tela mistura os aplicativos,
  excluindo Discord/Vesktop/FockyTV. O preview local é sempre silenciado.
  O helper WASAPI exige Windows 10 build 20348+ ou Windows 11. Se falhar,
  informa o erro e preserva o vídeo.
- No Linux/Vesktop, usa o áudio fornecido pelo seletor nativo/PipeWire,
  respeitando a opção de compartilhar sem som. Sem faixa de áudio fornecida
  pelo cliente, transmite apenas vídeo; o helper Windows não é chamado.
- O preview aparece como tile local na chamada do Discord. Usa a captura
  publicada, sem uma segunda sessão de vídeo ou reprodução do próprio áudio.
  O preview informa as dimensões ao Discord e aparece antes da negociação de rede.
- Passar o mouse sobre uma live FockyTV mostra uma miniatura no cartão nativo do
  Discord. A imagem é capturada sob demanda, sem reprodução de áudio, e usa o cache
  de previews do Discord. Uma conexão temporária usada só para a imagem é fechada
  depois da captura.
- Publicações só confirmam o início após o WebRTC conectar. A coleta ICE usa a configuração
  padrão do cliente, sem depender de STUN externo, e aproveita candidatos já
  coletados se a coleta demorar. A conexão falha após 20 segundos; rede/VPN
  e a porta de mídia do servidor ainda precisam permitir o tráfego WebRTC.
- Câmera não captura microfone; WHEP recebe áudio quando a live o oferece.
- Redireciona o início de tela e o comando de parar do Discord. O estado do
  botão e do preview é local; não cria um Go Live nos servidores Discord.
  Participantes **sem** o plugin não veem a live na call e assistem pelo site.
  O volume de stream do Discord e a prévia (miniatura) não se aplicam às lives FockyTV.
- A fonte escolhida no seletor usa captura desktop do Chromium (tela/janela).
  Fontes especiais, como câmeras escolhidas para Go Live ou o seletor nativo
  de macOS, ainda não são suportadas por essa integração.
- Inclui a liberação local de câmera e compartilhamento do experimento
  `2026-08-video-guard`; não exige GoLiveBypass para liberar os botões.
  Reinicie o Discord após ativar o plugin. Isso não altera bloqueios do servidor.
- Os patches dependem do código interno do Discord e podem precisar de ajuste
  após uma atualização.
- Captura usa as permissões e o seletor do Chromium/Electron. No Linux/Wayland,
  depende do portal disponível e da implementação de captura desktop do cliente.
- Sinalização HTTP usa o helper nativo; esta versão não suporta Vencord no navegador.
- Lives seguem a visibilidade do servidor FockyTV, não as permissões do canal Discord.

## Verificação

Instalador (Node.js 22+, sem alterar clientes reais):
`node --test installer/install.test.mjs`.
No PowerShell, o bootstrap também pode ser verificado sem downloads reais:
`powershell -NoProfile -ExecutionPolicy Bypass -File installer/bootstrap.test.ps1`.

Ciclo de vida da webcam remota (Node.js 22.13+): `node --test camera.test.mjs`.

Áudio que chega após o vídeo ou é republicado: `node --test playback.test.mjs`.

Qualidade dinâmica (Node.js 22.13+, com tsx): `pnpm exec tsx --test src/userplugins/fockytv/quality.test.ts`.

Com as ferramentas de desenvolvimento do Vencord:
`pnpm exec tsx src/userplugins/fockytv/self-check.ts`.

## Capturador de áudio Windows

`audio-helper.exe` e `audio-helper.cpp` são reutilizados do projeto FockyTV
(`electron/audio-helper/capture.cpp`). O Vencord embute o binário no helper
nativo; na primeira captura ele é materializado na pasta privada do cliente,
com verificação SHA-256. Parar a tela, sair da chamada ou fechar o cliente
encerra o capturador. Buffers preservam frames PCM e têm limite de tamanho.

Recompilação opcional (MinGW):
`x86_64-w64-mingw32-g++ -std=c++17 -O2 -static -o audio-helper.exe audio-helper.cpp -lole32 -lpsapi`.
