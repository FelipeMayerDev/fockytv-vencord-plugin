// SPDX-License-Identifier: GPL-3.0-or-later
import assert from "node:assert/strict";
import childProcess from "node:child_process";
import { createHash } from "node:crypto";
import { EventEmitter } from "node:events";
import { syncBuiltinESMExports } from "node:module";
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import test from "node:test";
import { MODS, buildPlugin, checkoutPlugin, discoverClients, enablePlugin, injectedBuild, modFor, portableGit, pruneBackups, readJSON, sameBuild, saveJSON, saveUpdateState, sourceFromBuild, startClient, stopClient, unpatchFolder } from "./install.mjs";

function fixture(t) {
    const root = mkdtempSync(join(tmpdir(), "FockyTV installer test "));
    t.after(() => rmSync(root, { recursive: true, force: true }));
    return root;
}
function file(path, data = "") { mkdirSync(dirname(path), { recursive: true }); writeFileSync(path, data); }
function source(root) {
    const directory = join(root, "Vencord");
    file(join(directory, "scripts", "build", "build.mjs"));
    mkdirSync(join(directory, "src", "webpack"), { recursive: true });
    return directory;
}

test("updater build scripts find the saved Node even when Discord has no Node on PATH", async t => {
    const root = fixture(t), checkout = source(root), result = join(root, "node-result.json");
    const original = { PATH: process.env.PATH, LOCALAPPDATA: process.env.LOCALAPPDATA, XDG_DATA_HOME: process.env.XDG_DATA_HOME };
    t.after(() => {
        for (const [key, value] of Object.entries(original)) {
            if (value === undefined) delete process.env[key]; else process.env[key] = value;
        }
    });
    process.env.PATH = join(root, "empty-bin");
    process.env.LOCALAPPDATA = process.env.XDG_DATA_HOME = root;
    file(join(checkout, "package.json"), JSON.stringify({ packageManager: "pnpm@10.0.0" }));
    const workspace = process.platform === "win32" ? join(root, "FockyTV", "build") : join(root, "fockytv", "build");
    file(join(workspace, "tools", "10.0.0", "node_modules", "pnpm", "bin", "pnpm.cjs"), `
        const { spawnSync } = require('node:child_process');
        const child = spawnSync('node', ['-p', 'process.execPath'], { encoding: 'utf8' });
        if (child.error || child.status !== 0) process.exit(1);
        require('node:fs').writeFileSync(${JSON.stringify(result)}, JSON.stringify({ node: child.stdout.trim(), cwd: process.cwd(), args: process.argv.slice(2) }));
    `);
    const { pnpmFor } = await import('./install.mjs?updater-node-path');
    const pnpm = await pnpmFor(checkout);
    pnpm(["build", "--disable-updater"]);
    assert.deepEqual(readJSON(result), { node: process.execPath, cwd: checkout, args: ["build", "--disable-updater"] });
});

test("portable Git verifies, extracts, validates and reuses the cached executable", async t => {
    const root = fixture(t), target = join(root, "Git cache");
    const archive = Buffer.from("verified archive fixture");
    const url = "https://github.com/git-for-windows/git/releases/download/v2.56.0.windows.2/MinGit-2.56.0.2-64-bit.zip";
    const requests = [];
    t.mock.method(globalThis, "fetch", async address => {
        requests.push(address);
        return address === url ? new Response(archive) : Response.json({ assets: [{
            name: "MinGit-2.56.0.2-64-bit.zip", browser_download_url: url,
            digest: `sha256:${createHash("sha256").update(archive).digest("hex")}`
        }] });
    });
    const commands = [];
    t.mock.method(childProcess, "spawnSync", (command, args, options) => {
        commands.push(command);
        assert.equal(options?.windowsHide, true, "Updates run without a console: every child must stay hidden");
        if (command === "powershell.exe") {
            assert.deepEqual(readFileSync(options.env.FOCKYTV_GIT_ZIP), archive);
            assert.ok(args.includes("-NonInteractive"));
            file(join(options.env.FOCKYTV_GIT_TARGET, "cmd", "git.exe"), "git fixture");
        } else assert.deepEqual(args, ["--version"]);
        return { status: 0 };
    });
    syncBuiltinESMExports();
    t.after(() => { t.mock.restoreAll(); syncBuiltinESMExports(); });
    const git = await portableGit(target);
    assert.equal(git, join(target, "cmd", "git.exe"));
    assert.equal(readFileSync(git, "utf8"), "git fixture");
    assert.deepEqual(readdirSync(root), ["Git cache"]);
    assert.equal(commands.length, 2);
    assert.equal(await portableGit(target), git);
    assert.equal(requests.length, 2, "Cached Git must not be downloaded again");
    assert.equal(commands.length, 2);
});

test("portable Git rejects a bad checksum before extraction and preserves existing files", async t => {
    const root = fixture(t), target = join(root, "git");
    file(join(target, "keep"), "existing data");
    let requests = 0;
    t.mock.method(globalThis, "fetch", async () => ++requests === 1 ? Response.json({ assets: [{
        name: "MinGit-2.56.0.2-64-bit.zip", digest: `sha256:${"0".repeat(64)}`,
        browser_download_url: "https://github.com/git-for-windows/git/releases/download/test/MinGit-2.56.0.2-64-bit.zip"
    }] }) : new Response("tampered archive"));
    await assert.rejects(portableGit(target), /Checksum Git invalido/);
    assert.equal(readFileSync(join(target, "keep"), "utf8"), "existing data");
    assert.deepEqual(readdirSync(root), ["git"]);
});

test("portable Git rejects release metadata without a trusted download and SHA-256", async t => {
    const root = fixture(t);
    for (const asset of [undefined, { name: "MinGit-2.56.0.2-64-bit.zip" }, {
        name: "MinGit-2.56.0.2-64-bit.zip", digest: `sha256:${"0".repeat(64)}`,
        browser_download_url: "https://example.com/git.zip"
    }]) {
        const fetch = t.mock.method(globalThis, "fetch", async () => Response.json({ assets: asset ? [asset] : [] }));
        await assert.rejects(portableGit(join(root, "git")), /Manifesto Git invalido/);
        fetch.mock.restore();
    }
    assert.deepEqual(readdirSync(root), []);
});

test("Windows without Git falls back when winget is missing or fails", async t => {
    const platform = Object.getOwnPropertyDescriptor(process, "platform");
    const environment = { ...process.env };
    t.after(() => {
        Object.defineProperty(process, "platform", platform);
        for (const key of Object.keys(process.env)) if (!(key in environment)) delete process.env[key];
        Object.assign(process.env, environment);
        t.mock.restoreAll();
        syncBuiltinESMExports();
    });
    Object.defineProperty(process, "platform", { value: "win32" });
    let commands = [], downloads = 0;
    t.mock.method(childProcess, "spawnSync", command => {
        commands.push(command);
        return { status: 1 };
    });
    syncBuiltinESMExports();
    t.mock.method(globalThis, "fetch", async () => { downloads++; return new Response("offline", { status: 503 }); });
    for (const winget of [false, true]) {
        const root = fixture(t), bin = join(root, "bin");
        mkdirSync(bin);
        if (winget) { file(join(bin, "winget.exe"), "fixture"); chmodSync(join(bin, "winget.exe"), 0o755); }
        process.env.PATH = bin;
        process.env.LOCALAPPDATA = root;
        process.env.ProgramFiles = join(root, "Program Files");
        commands = [];
        downloads = 0;
        const { ensureGit } = await import(`./install.mjs?git-fallback=${winget}`);
        await assert.rejects(ensureGit(), /Manifesto Git HTTP 503/);
        assert.equal(downloads, 1, "Fallback must attempt the MinGit manifest");
        assert.deepEqual(commands, winget ? ["winget.exe"] : []);
    }
});

test("reads Vencord ASAR injection and locates its original checkout", t => {
    const root = fixture(t), checkout = source(root), resources = join(root, "Discord", "resources");
    const patcher = join(checkout, "dist", "patcher.js");
    file(join(resources, "app.asar"), Buffer.concat([Buffer.alloc(32), Buffer.from(`require(${JSON.stringify(patcher)})`)]));
    assert.equal(injectedBuild(resources), patcher);
    rmSync(join(resources, "app.asar"));
    file(join(resources, "app.asar", "index.js"), `require(${JSON.stringify(patcher)});`);
    assert.equal(injectedBuild(resources), patcher);
    assert.equal(sourceFromBuild(patcher), checkout);
    assert.equal(sourceFromBuild(join(root, "missing")), undefined);
});

test("Equicord re-injection after a Discord update keeps the build and is undone before Equilotl", t => {
    const root = fixture(t), checkout = source(root), resources = join(root, "resources");
    const patcher = join(checkout, "dist", "desktop", "patcher.js");
    file(join(resources, "_app.asar"), "original");
    file(join(resources, "app.asar", "index.js"), `require(${JSON.stringify(patcher)});`);
    assert.equal(sameBuild(injectedBuild(resources), checkout, MODS.equicord), true);
    assert.equal(sameBuild(join(checkout, "dist", "desktop"), checkout, MODS.equicord), true);
    assert.equal(sameBuild(join(root, "other", "dist", "desktop", "patcher.js"), checkout, MODS.equicord), false);
    assert.equal(sameBuild(undefined, checkout, MODS.vencord), false);
    unpatchFolder(resources);
    assert.equal(readFileSync(join(resources, "app.asar"), "utf8"), "original");
    assert.equal(existsSync(join(resources, "_app.asar")), false);
    unpatchFolder(resources);
    assert.equal(readFileSync(join(resources, "app.asar"), "utf8"), "original", "A file app.asar is left to the official installer");
});

test("ordinary Discord ASAR is not mistaken for Vencord", t => {
    const root = fixture(t);
    file(join(root, "app.asar"), 'require("./core.asar")');
    assert.equal(injectedBuild(root), undefined);
});

test("client discovery selects newest Discord version and Vesktop state", t => {
    const root = fixture(t), checkout = source(root), config = join(root, "config"), local = join(root, "local");
    const installation = process.platform === "win32" ? join(local, "Discord") : join(config, "discord");
    file(join(installation, "app-1.0.9", "resources", "app.asar"));
    const newest = join(installation, "app-1.0.10", "resources");
    file(join(newest, "app.asar"), `require(${JSON.stringify(join(checkout, "dist", "patcher.js"))})`);
    const profile = join(config, "vesktop");
    file(join(profile, "state.json"), JSON.stringify({ vencordDir: join(checkout, "dist"), maximized: true }));
    const clients = discoverClients({ HOME: root, USERPROFILE: root, APPDATA: config, LOCALAPPDATA: local });
    assert.equal(clients.find(client => client.resources === newest)?.source, checkout);
    assert.equal(clients.some(client => client.resources === join(installation, "app-1.0.9", "resources")), false);
    mkdirSync(join(installation, "app-1.0.11", "resources"), { recursive: true });
    const updating = discoverClients({ HOME: root, USERPROFILE: root, APPDATA: config, LOCALAPPDATA: local });
    assert.equal(updating.find(client => client.id === "discord")?.resources, newest, "A Discord update still downloading is skipped");
    const vesktop = clients.filter(client => client.profile === profile);
    assert.equal(vesktop.length, 1);
    assert.equal(vesktop[0].source, checkout);
    assert.equal(vesktop[0].settings, join(profile, "settings", "settings.json"));
});

test("Equicord injection is recognized with its own build, installer and settings", t => {
    const root = fixture(t), checkout = source(root), config = join(root, "config"), local = join(root, "local");
    mkdirSync(join(checkout, "src", "equicordplugins"));
    const installation = process.platform === "win32" ? join(local, "Discord") : join(config, "discord");
    const resources = join(installation, "app-1.0.10", "resources");
    file(join(resources, "_app.asar"));
    file(join(resources, "app.asar"), `require(${JSON.stringify(join(checkout, "dist", "desktop"))})`);
    const client = discoverClients({ HOME: root, USERPROFILE: root, APPDATA: config, LOCALAPPDATA: local }).find(client => client.resources === resources);
    assert.equal(client.source, checkout);
    const mod = modFor(client.source);
    assert.equal(mod, MODS.equicord);
    assert.equal(resolve(client.build), resolve(mod.patcher(checkout)));
    assert.equal(mod.settings(client), join(config, "Equicord", "settings", "settings.json"));
    assert.equal(modFor(join(root, "Equicord", "equicord.asar")), MODS.equicord);
    assert.equal(modFor(join(root, "Vencord", "vencord.asar")), MODS.vencord);
});

test("Linux discovers Discord and Vesktop Flatpak profiles", { skip: process.platform !== "linux" }, t => {
    const root = fixture(t), config = join(root, "config");
    const location = join(root, ".local", "share", "flatpak", "app", "com.discordapp.Discord");
    file(join(location, "current", "active", "files", "discord", "app-1.0.10", "resources", "app.asar"));
    const profile = join(root, ".var", "app", "dev.vencord.Vesktop", "config", "vesktop");
    file(join(profile, "state.json"), "{}");
    const modern = join(root, ".var", "app", "com.discordapp.DiscordPTB", "config", "discord");
    file(join(modern, "app-1.0.20", "resources", "app.asar"));
    const clients = discoverClients({ HOME: root, XDG_CONFIG_HOME: config });
    assert.equal(clients.find(client => client.location === modern).flatpak, "com.discordapp.DiscordPTB");
    const discord = clients.find(client => client.location === location);
    assert.equal(discord.flatpak, "com.discordapp.Discord");
    assert.equal(discord.settings, join(root, ".var", "app", "com.discordapp.Discord", "config", "Vencord", "settings", "settings.json"));
    assert.equal(clients.find(client => client.profile === profile).flatpak, "dev.vencord.Vesktop");
});

test("activation preserves other plugins and settings, with a recoverable backup", t => {
    const root = fixture(t), settings = join(root, "settings.json");
    const original = { theme: "dark", plugins: { Other: { enabled: true }, FakeNitro: { enabled: false, enableEmojiBypass: false }, FockyTV: { url: "https://tv.example", nick: "Rubi", enabled: false } } };
    file(settings, JSON.stringify(original));
    saveJSON(settings, enablePlugin(readJSON(settings)));
    const updated = readJSON(settings);
    assert.equal(updated.plugins.FockyTV.enabled, true);
    assert.equal(updated.plugins.FockyTV.nick, "Rubi");
    assert.equal(updated.plugins.FockyTV.url, undefined);
    assert.deepEqual(updated.plugins.FakeNitro, { enabled: true, enableEmojiBypass: false });
    assert.deepEqual(updated.plugins.Other, original.plugins.Other);
    assert.equal(updated.theme, "dark");
    const backup = readdirSync(root).find(name => name.startsWith("settings.json.fockytv-backup-"));
    assert.deepEqual(readJSON(join(root, backup)), original);
});

test("only the three newest build backups are kept; the live dist and other folders are untouched", t => {
    const root = fixture(t);
    const stamps = ["2026-10-15T20-00-33-082Z", "2026-10-16T00-51-55-236Z", "2026-10-16T17-30-31-020Z", "2026-10-16T20-06-20-285Z", "2026-10-16T21-37-09-007Z"];
    for (const stamp of stamps) file(join(root, `dist.fockytv-backup-${stamp}`, "renderer.js"), stamp);
    file(join(root, "dist", "renderer.js"), "current");
    file(join(root, "fockytv-debug-backup-20261015", "dist", "renderer.js"), "user");
    pruneBackups(root, "dist.fockytv-backup-");
    assert.deepEqual(readdirSync(root).sort(), ["dist", ...stamps.slice(-3).map(stamp => `dist.fockytv-backup-${stamp}`), "fockytv-debug-backup-20261015"].sort());
    pruneBackups(join(root, "missing"), "");
});

test("activation drops any client-side server address for new and legacy installations", () => {
    for (const settings of [{}, { plugins: { FockyTV: { url: "https://tv.huestavo.com" } } }, { plugins: { FockyTV: { url: "https://fockytv-insider.felipemayer.com.br" } } }]) {
        const plugins = enablePlugin(settings).plugins;
        const plugin = plugins.FockyTV;
        assert.equal(plugin.enabled, true);
        assert.equal(plugins.FakeNitro.enabled, true);
        assert.equal(plugin.url, undefined);
    }
});

test("update metadata records the installed revision and Node for both build layouts", t => {
    for (const equicord of [false, true]) {
        const checkout = source(fixture(t));
        if (equicord) mkdirSync(join(checkout, "src", "equicordplugins"));
        const directory = join(checkout, "dist", equicord ? "desktop" : "");
        mkdirSync(directory, { recursive: true });
        const client = { id: "discord", location: join(checkout, "Discord") };
        saveUpdateState(checkout, client, "a".repeat(40));
        assert.deepEqual(readJSON(join(directory, "fockytv-update.json")), {
            source: checkout, client: "discord", target: client.location, revision: "a".repeat(40), branch: "main", node: process.execPath
        });
        saveUpdateState(checkout, client, "a".repeat(40), "insider");
        assert.equal(readJSON(join(directory, "fockytv-update.json")).branch, "insider");
        assert.throws(() => saveUpdateState(checkout, client, "a".repeat(40), "other"), /Canal/);
        assert.throws(() => saveUpdateState(checkout, client, "invalid"), /Revisao/);
    }
});

test("cached plugin checkout switches channels, pins the checked revision and preserves local edits", t => {
    const root = fixture(t), origin = join(root, "origin"), checkout = join(root, "cached");
    const git = (...args) => {
        const result = childProcess.spawnSync("git", args, { encoding: "utf8" });
        assert.equal(result.status, 0, result.stderr || String(result.error));
        return result.stdout.trim();
    };
    git("init", "--initial-branch", "main", origin);
    git("-C", origin, "config", "user.name", "Test");
    git("-C", origin, "config", "user.email", "test@example.invalid");
    file(join(origin, "index.tsx"), "stable");
    git("-C", origin, "add", "."); git("-C", origin, "commit", "-m", "stable");
    const stable = git("-C", origin, "rev-parse", "HEAD");
    git("-C", origin, "checkout", "-b", "insider");
    file(join(origin, "index.tsx"), "experimental");
    git("-C", origin, "commit", "-am", "experimental");
    const insider = git("-C", origin, "rev-parse", "HEAD");
    git("clone", origin, checkout);
    checkoutPlugin("git", checkout, "main");
    assert.equal(git("-C", checkout, "rev-parse", "HEAD"), stable);
    checkoutPlugin("git", checkout, "insider");
    assert.equal(git("-C", checkout, "rev-parse", "HEAD"), insider);
    checkoutPlugin("git", checkout, "insider", stable);
    assert.equal(git("-C", checkout, "rev-parse", "HEAD"), stable, "Install exactly the revision already checked");
    file(join(checkout, "index.tsx"), "local work");
    assert.throws(() => checkoutPlugin("git", checkout, "insider"));
    assert.equal(readFileSync(join(checkout, "index.tsx"), "utf8"), "local work");
    assert.throws(() => checkoutPlugin("git", checkout, "../../bad"), /Canal/);
    assert.throws(() => checkoutPlugin("git", checkout, "main", "--option"), /Revisao/);
    assert.equal(enablePlugin({}, "insider").plugins.FockyTV.updateBranch, "insider");
    assert.equal(enablePlugin({ plugins: { FockyTV: { updateBranch: "insider" } } }).plugins.FockyTV.updateBranch, "insider");
});

test("malformed settings are rejected without overwriting them", t => {
    const root = fixture(t), settings = join(root, "settings.json");
    file(settings, '{"plugins":');
    assert.throws(() => readJSON(settings));
    assert.equal(readFileSync(settings, "utf8"), '{"plugins":');
    file(settings, "[]");
    assert.throws(() => readJSON(settings), /JSON invalido/);
});

for (const [failure, equicord] of [["none", false], ["build", false], ["incomplete", false], ["none", true], ["incomplete", true]]) {
    test(`${equicord ? "Equicord " : ""}build preserves unrelated plugins and restores files on ${failure}`, t => {
        const root = fixture(t), checkout = source(root), plugin = join(root, "plugin");
        if (equicord) mkdirSync(join(checkout, "src", "equicordplugins"));
        const plugins = join(checkout, "src", "userplugins"), destination = join(plugins, "fockytv");
        file(join(destination, "index.tsx"), "old plugin");
        file(join(plugins, "Other", "index.tsx"), "other plugin");
        file(join(checkout, "dist", "patcher.js"), "old build");
        file(join(plugin, "index.tsx"), "new plugin");
        file(join(plugin, "native.ts"), "native helper");
        file(join(plugin, "audio-helper.exe"), "audio helper");
        file(join(plugin, "style.css"), "plugin styles");
        file(join(plugin, "jetta.png"), "jetta image");
        file(join(plugin, "jetta.mp3"), "jetta audio");
        file(join(plugin, "installer", "install.mjs"), "must not be copied");
        const commands = [];
        const pnpm = args => {
            commands.push(args[0]);
            if (args[0] !== "build") return;
            assert.deepEqual(readdirSync(plugins).sort(), ["Other", "fockytv"]);
            file(join(checkout, "dist", "partial.js"), "partial build");
            if (failure === "build") throw new Error("build failed");
            if (failure === "none") for (const name of (equicord ? MODS.equicord : MODS.vencord).files) file(join(checkout, "dist", name), "new build");
            if (failure === "incomplete" && equicord) for (const name of MODS.vencord.files) file(join(checkout, "dist", name), "wrong layout");
        };
        if (failure === "none") {
            assert.equal(buildPlugin(checkout, plugin, pnpm), join(checkout, "dist"));
            assert.equal(readFileSync(join(destination, "index.tsx"), "utf8"), "new plugin");
            assert.equal(existsSync(join(destination, "installer")), false);
            assert.equal(existsSync(join(destination, "audio-helper.exe")), true);
            assert.equal(readFileSync(join(destination, "jetta.png"), "utf8"), "jetta image", "Bundled images must reach the build");
            assert.equal(readFileSync(join(destination, "jetta.mp3"), "utf8"), "jetta audio", "Bundled audio must reach the build");
            assert.equal(readFileSync(join(destination, "style.css"), "utf8"), "plugin styles", "The plugin imports its stylesheet at build time");
        } else {
            assert.throws(() => buildPlugin(checkout, plugin, pnpm), failure === "build" ? /build failed/ : /Build incompleta/);
            assert.equal(readFileSync(join(destination, "index.tsx"), "utf8"), "old plugin");
            assert.equal(readFileSync(join(checkout, "dist", "patcher.js"), "utf8"), "old build");
            assert.equal(existsSync(join(checkout, "dist", "partial.js")), false);
        }
        assert.equal(readFileSync(join(plugins, "Other", "index.tsx"), "utf8"), "other plugin");
        assert.deepEqual(commands, ["exec", "build"]);
    });
}

test("Linux bootstrap rejects a tampered Node archive before extraction", { skip: process.platform !== "linux" }, async t => {
    const { spawnSync } = await import("node:child_process");
    const root = fixture(t), bin = join(root, "bin"), temporary = join(root, "tmp");
    mkdirSync(temporary);
    const stub = (name, text) => { file(join(bin, name), '#!/bin/sh\n' + text); chmodSync(join(bin, name), 0o755); };
    stub("node", "exit 1\n");
    stub("curl", `args="$*"
while [ "$#" -gt 0 ]; do
    if [ "$1" = -o ]; then shift; output="$1"; fi
    shift
done
case "$args" in
    *SHASUMS256.txt*) printf '%064d  node-v24.0.0-linux-x64.tar.xz\\n' 0 > "$output" ;;
    *) printf 'tampered archive' > "$output" ;;
esac
`);
    stub("tar", 'touch "$FOCKYTV_TEST_EXTRACTED"\nexit 99\n');
    const result = spawnSync("bash", [join(import.meta.dirname, "install.sh")], {
        env: { ...process.env, PATH: bin + ":" + process.env.PATH, XDG_DATA_HOME: join(root, "data"), TMPDIR: temporary, FOCKYTV_TEST_EXTRACTED: join(root, "extracted") },
        encoding: "utf8"
    });
    assert.notEqual(result.status, 0);
    assert.match(result.stdout + result.stderr, /FAILED|checksum/i);
    assert.equal(existsSync(join(root, "extracted")), false);
    assert.deepEqual(readdirSync(temporary), []);
});


test("updates reopen the selected client independently and report launch failures", async t => {
    const environment = { ...process.env };
    const platform = Object.getOwnPropertyDescriptor(process, "platform");
    t.after(() => {
        for (const key of Object.keys(process.env)) if (!(key in environment)) delete process.env[key];
        Object.assign(process.env, environment);
        Object.defineProperty(process, "platform", platform);
        t.mock.restoreAll();
        syncBuiltinESMExports();
    });
    process.env.ELECTRON_RUN_AS_NODE = "1";
    let expectedCommand, expectedArgs, failure = false, unrefs = 0;
    t.mock.method(childProcess, "spawn", (command, args, options) => {
        assert.equal(command, expectedCommand);
        assert.deepEqual(args, expectedArgs);
        assert.equal(options.detached, true);
        assert.equal(options.stdio, "ignore");
        assert.equal(options.env.ELECTRON_RUN_AS_NODE, undefined);
        assert.equal(options.cwd, expectedCommand === "flatpak" ? undefined : dirname(expectedCommand));
        const child = new EventEmitter();
        child.unref = () => { unrefs++; };
        process.nextTick(() => failure ? child.emit("error", new Error("launch failed")) : child.emit("spawn"));
        return child;
    });
    syncBuiltinESMExports();
    for (const platform of ["win32", "linux"]) {
        Object.defineProperty(process, "platform", { value: platform });
        for (const name of ["Discord", "Discord PTB", "Discord Canary", "Vesktop.AppImage"]) {
            expectedCommand = join(fixture(t), name);
            expectedArgs = [];
            await startClient({ id: name.startsWith("Discord") ? "discord" : "vesktop", location: dirname(expectedCommand) }, expectedCommand);
        }
    }
    expectedCommand = "flatpak";
    expectedArgs = ["run", "dev.vencord.Vesktop"];
    await startClient({ flatpak: "dev.vencord.Vesktop" }, "/app/vesktop");
    assert.equal(unrefs, 9);
    failure = true;
    await assert.rejects(startClient({ flatpak: "dev.vencord.Vesktop" }, "/app/vesktop"), /launch failed/);
    assert.equal(unrefs, 9, "Failed launches must not be reported as reopened");
    assert.equal(process.env.ELECTRON_RUN_AS_NODE, "1", "Installer environment stays intact");
});

test("Windows Discord relaunch uses the installation launcher for Stable, PTB and Canary", async t => {
    const platform = Object.getOwnPropertyDescriptor(process, "platform");
    Object.defineProperty(process, "platform", { value: "win32" });
    t.after(() => { Object.defineProperty(process, "platform", platform); t.mock.restoreAll(); syncBuiltinESMExports(); });
    let expectedLauncher, expectedExecutable, exitCode = 0, unrefs = 0;
    t.mock.method(childProcess, "spawn", (command, args, options) => {
        assert.equal(command, expectedLauncher);
        assert.deepEqual(args, ["--processStart", expectedExecutable]);
        assert.equal(options.cwd, dirname(expectedLauncher));
        assert.equal(options.env.ELECTRON_RUN_AS_NODE, undefined);
        assert.equal(options.detached, true);
        assert.equal(options.windowsHide, true);
        const child = new EventEmitter();
        child.unref = () => unrefs++;
        process.nextTick(() => { child.emit("spawn"); child.emit("exit", exitCode); });
        return child;
    });
    syncBuiltinESMExports();
    for (const name of ["Discord", "DiscordPTB", "DiscordCanary"]) {
        const location = join(fixture(t), `${name} with spaces & accents é`);
        expectedLauncher = join(location, "Update.exe");
        expectedExecutable = `${name}.exe`;
        file(expectedLauncher);
        // A pasta antiga pode ter sido removida enquanto o instalador estava compilando.
        await startClient({ id: "discord", name, location }, join(location, "app-1.0.1", expectedExecutable));
    }
    assert.equal(unrefs, 3);
    exitCode = 1;
    await assert.rejects(startClient({ id: "discord", location: dirname(expectedLauncher) }, join(dirname(expectedLauncher), "app-old", expectedExecutable)), /codigo 1/);
    assert.equal(unrefs, 3, "A failed launcher must not be reported as reopened");
});

test("Windows update closes client executables without killing the child installer", t => {
    const platform = Object.getOwnPropertyDescriptor(process, "platform");
    Object.defineProperty(process, "platform", { value: "win32" });
    t.after(() => { Object.defineProperty(process, "platform", platform); t.mock.restoreAll(); syncBuiltinESMExports(); });
    for (const client of [
        { id: "discord", name: "Discord" }, { id: "discord", name: "Discord PTB" },
        { id: "discord", name: "Discord Canary" }, { id: "vesktop", name: "Vesktop" }
    ]) {
        let running = true;
        const killed = [];
        const mock = t.mock.method(childProcess, "spawnSync", (command, args) => {
            if (command === "tasklist.exe") return { status: 0, stdout: running ? `"${args[1].slice("IMAGENAME eq ".length)}","123"` : "" };
            assert.equal(command, "taskkill.exe");
            assert.deepEqual(args, ["/IM", args[1], "/F"]);
            assert.ok(args[1].toLowerCase().replaceAll("-", "").startsWith(client.name.toLowerCase().replaceAll(" ", "")));
            killed.push(args[1]);
            running = false;
            return { status: 0 };
        });
        syncBuiltinESMExports();
        stopClient(client);
        assert.ok(killed.length > 0);
        mock.mock.restore();
    }
});
