// SPDX-License-Identifier: GPL-3.0-or-later
import assert from "node:assert/strict";
import test from "node:test";
import { watchParty, watchPosition, youtubeId } from "./watch-party";

test("soundboard usa o relay entre pares da chamada, valida mensagens e limpa pares ao reconectar", () => {
    const sockets: any[] = [], sent: any[] = [], heard: any[] = [];
    class Socket {
        readyState = 1;
        onopen?: () => void;
        onmessage?: (event: any) => void;
        onclose?: () => void;
        constructor() { sockets.push(this); }
        send(data: string) { sent.push(JSON.parse(data)); }
        close() { this.onclose?.(); }
    }
    const player = watchParty({ base: () => "https://tv.example", fetch: async () => { throw new Error("sem download"); }, Socket: Socket as any });
    const stop = player.onSound((clip, from) => heard.push({ clip, from }));
    const clip = { soundId: "123456789012345678", volume: 0.5 };
    const message = (value: object) => sockets.at(-1).onmessage({ data: JSON.stringify(value) });
    try {
        assert.equal(player.sendSound(clip), false);
        player.connect("123456", { id: "111111", name: "Ana" });
        sockets[0].onopen();
        message({ type: "peers", peers: ["222222", "111111", "invalid"] });
        message({ type: "peer-joined", nick: "333333" });
        sent.length = 0;
        assert.equal(player.sendSound(clip), true);
        assert.deepEqual(sent, ["222222", "333333"].map(to => ({ type: "soundboard", to, clip })));
        const remote = { type: "soundboard", from: "222222", to: "111111", clip };
        message(remote);
        assert.deepEqual(heard, [{ clip, from: "222222" }]);
        message({ ...remote, from: "444444" });
        message({ ...remote, to: "333333" });
        message({ ...remote, clip: { soundId: "https://evil.test", volume: 1 } });
        assert.equal(heard.length, 1);
        message({ type: "peer-left", nick: "222222" });
        message(remote);
        sent.length = 0;
        player.sendSound(clip);
        assert.deepEqual(sent.map(message => message.to), ["333333"]);
        player.connect("654321", { id: "111111", name: "Ana" });
        sockets[1].onopen();
        sent.length = 0;
        player.sendSound(clip);
        assert.equal(sent.length, 0, "não envia para participantes da chamada anterior");
        sockets[0].onmessage({ data: JSON.stringify(remote) });
        assert.equal(heard.length, 1, "conexão anterior não toca sons");
        stop();
        message({ type: "peer-joined", nick: "222222" });
        message(remote);
        assert.equal(heard.length, 1);
    } finally { stop(); player.connect(); }
});

test("links do YouTube e posição usam apenas hosts válidos e tempo decorrido", () => {
    for (const link of ["aaaaaaaaaaa", "https://youtu.be/aaaaaaaaaaa?t=3", "https://www.youtube.com/watch?v=aaaaaaaaaaa", "https://youtube.com/shorts/aaaaaaaaaaa", "https://m.youtube.com/live/aaaaaaaaaaa"])
        assert.equal(youtubeId(link), "aaaaaaaaaaa");
    for (const link of ["https://evil.test/watch?v=aaaaaaaaaaa", "https://youtube.com.evil.test/watch?v=aaaaaaaaaaa", "https://youtu.be/short", "javascript:aaaaaaaaaaa", "nope"])
        assert.equal(youtubeId(link), null);
    const state = { type: "yt", action: "state", videoId: "aaaaaaaaaaa", playing: true, pos: 20 } as const;
    assert.equal(watchPosition(state, 2500), 22.5);
    assert.equal(watchPosition({ ...state, playing: false }, 2500), 20);
    assert.equal(watchPosition(null, 1000), 0);
});

test("jam aplica snapshot tardio, controles, troca durante download e limpeza", async context => {
    let clock = 1000;
    context.mock.method(performance, "now", () => clock);
    context.mock.timers.enable({ apis: ["setInterval"] });
    const sockets: any[] = [];
    const sent: any[] = [];
    class Socket {
        readyState = 1;
        onopen?: () => void;
        onmessage?: (event: any) => void;
        onclose?: () => void;
        constructor(public url: string) { sockets.push(this); }
        send(text: string) { sent.push(JSON.parse(text)); }
        close() { this.onclose?.(); }
    }
    const media: any = {
        readyState: 1, duration: 100, currentTime: 0, paused: true, ended: false, src: "",
        pause() { this.paused = true; }, load() {}, removeAttribute() { this.src = ""; },
        async play() { this.paused = false; }
    };
    const audio: any = {
        readyState: 1, duration: 100, currentTime: 0, paused: true, ended: false, src: "", playbackRate: 1,
        pause() { this.paused = true; }, load() {}, removeAttribute() { this.src = ""; },
        async play() { this.paused = false; }
    };
    let failNext = false, badMetaNext = false;
    let resolveFirst!: (response: any) => void;
    const metaUrl = "https://rr1---sn-okz.googlevideo.com/videoplayback?expire=1&ip=10.0.0.1";
    const audioUrl = "https://rr3---sn-okz.googlevideo.com/videoplayback?expire=1&ip=10.0.0.1&itag=140";
    const streamSrc = `https://tv.example/api/fixed/jam/yt/stream?u=${encodeURIComponent(metaUrl)}`;
    const audioSrc = `https://tv.example/api/fixed/jam/yt/stream?u=${encodeURIComponent(audioUrl)}`;
    const meta = (extra: object = {}) => ({ status: 200, type: "application/json", body: new TextEncoder().encode(JSON.stringify({ title: "B", duration: 100, url: metaUrl, audioUrl, ...extra })) });
    const fetch = async (url: string) => {
        if (url.includes("id=aaaaaaaaaaa")) return new Promise<any>(resolve => { resolveFirst = resolve; });
        if (failNext) { failNext = false; throw new Error("temporary failure"); }
        if (badMetaNext) { badMetaNext = false; return meta({ url: undefined }); }
        return meta();
    };
    const player = watchParty({ base: () => "https://tv.example", fetch, Socket: Socket as any, makeAudio: () => audio });
    const message = (videoId: string, playing = true, pos = 30) => sockets.at(-1).onmessage({ data: JSON.stringify({ type: "yt", action: "state", videoId, playing, pos }) });
    const flush = async () => { await new Promise(resolve => setImmediate(resolve)); };
    try {
        player.connect("123456", { id: "111111", name: "Ana" });
        assert.match(sockets[0].url, /watch%3A123456/);
        sockets[0].onopen();
        player.attach(media);
        message("bbbbbbbbbbb");
        await flush();
        assert.equal(media.src, "", "entrar na call não começa a assistir");
        player.listen(true);
        assert.deepEqual(sent.at(-1), { type: "yt", action: "listen", on: true });
        message("aaaaaaaaaaa");
        message("bbbbbbbbbbb", false, 40);
        await flush();
        media.onloadedmetadata();
        assert.equal(media.src, streamSrc, "vídeo toca pela stream temporária via proxy do servidor");
        assert.equal(audio.src, audioSrc, "som toca pelo áudio separado, também via proxy");
        assert.equal(media.muted, true, "som não dobra com o vídeo mudo");
        assert.equal(media.currentTime, 40, "snapshot pausado ajusta a posição");
        assert.equal(audio.currentTime, 40, "áudio segue a posição do vídeo");
        assert.ok(media.paused);
        const secondSrc = media.src;
        assert.equal(player.snapshot().title, "B");
        assert.equal(player.duration(), 100);
        resolveFirst({ status: 200, type: "application/json", body: new TextEncoder().encode(JSON.stringify({ title: "A", duration: 100, url: metaUrl })) });
        await flush();
        assert.equal(media.src, secondSrc, "download anterior não sobrescreve vídeo novo");
        message("bbbbbbbbbbb", true, 50);
        assert.ok(media.currentTime >= 50 && media.currentTime < 51);
        assert.equal(media.paused, false);
        assert.ok(audio.currentTime >= 50 && audio.currentTime < 51, "áudio busca a posição no hard seek");
        assert.equal(audio.paused, false, "áudio acompanha o play");
        player.control(false, 60);
        assert.deepEqual(sent.at(-1), { type: "yt", action: "state", videoId: "bbbbbbbbbbb", playing: false, pos: 60 });
        player.load("ccccccccccc");
        assert.equal(sent.at(-1).action, "load");
        sockets[0].onmessage({ data: "null" });
        sockets[0].onmessage({ data: "malformed" });
        assert.equal(player.snapshot().state?.videoId, "bbbbbbbbbbb");
        player.setVolume(0.8, 0.5);
        assert.equal(media.volume, 0.4);
        assert.equal(audio.volume, 0.4, "volume vale para o áudio separado");
        assert.equal(player.snapshot().volume, 0.8);
        sockets[0].onmessage({ data: JSON.stringify({ type: "yt", action: "members", viewers: ["111111", "222222"] }) });
        assert.deepEqual(player.snapshot().viewers, ["111111", "222222"]);
        sockets[0].onmessage({ data: JSON.stringify({ type: "yt", action: "members", viewers: [null] }) });
        assert.deepEqual(player.snapshot().viewers, ["111111", "222222"], "presença inválida é ignorada");
        sockets[0].onmessage({ data: JSON.stringify({ type: "yt", action: "state", uid: "track-1", queue: [{ uid: "track-1", id: "bbbbbbbbbbb", title: "B" }], videoId: "bbbbbbbbbbb", playing: true, pos: 50 }) });
        media.onended();
        assert.deepEqual(sent.at(-1), { type: "yt", action: "next", uid: "track-1" });
        player.add("ccccccccccc", "C");
        assert.deepEqual(sent.at(-1), { type: "yt", action: "add", videoId: "ccccccccccc", title: "C" });
        player.listen(false);
        assert.equal(media.src, "");
        assert.equal(audio.src, "", "sair limpa o áudio separado");
        assert.equal(media.paused, true);
        assert.equal(player.snapshot().watching, false);
        message("bbbbbbbbbbb", true, 55);
        await flush();
        assert.equal(media.src, "", "sair continua recebendo o estado sem baixar ou tocar vídeo");
        player.listen(true);
        await flush();
        media.onloadedmetadata();
        assert.ok(media.currentTime >= 55, "reentrar sincroniza automaticamente");
        failNext = true;
        media.onerror();
        clock += 6000;
        context.mock.timers.tick(1000);
        await flush();
        assert.match(player.snapshot().error, /temporary failure/);
        clock += 6000;
        context.mock.timers.tick(1000);
        await flush();
        media.onloadedmetadata();
        assert.equal(player.snapshot().error, "");
        assert.ok(media.src, "download com falha é repetido automaticamente");
        badMetaNext = true;
        media.onerror();
        clock += 6000;
        context.mock.timers.tick(1000);
        await flush();
        assert.match(player.snapshot().error, /indisponível/, "meta sem url de stream é rejeitada");
        sockets[0].onclose();
        assert.equal(media.paused, true, "desconectado não segue tocando sem sincronismo");
        player.connect("654321", { id: "111111", name: "Ana" });
        assert.equal(player.snapshot().state, null);
        assert.equal(media.src, "");
        assert.match(sockets[1].url, /watch%3A654321/);
    } finally { player.connect(); player.attach(); }
});
